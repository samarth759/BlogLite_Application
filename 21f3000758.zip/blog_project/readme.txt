## Steps to run :-

1. Create a virtual environment using ` python python -m venv .venv`.
2. Navigate inside the virtual environment.
3. activate the virtual environment using '.\scripts\activate'
4. Install the packages required using `pip install -r requirements.txt`
5. After all the packages are installed, its time to finally run the app.

- Run the app using `python main.py`